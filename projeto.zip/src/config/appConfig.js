export default {
    IP: "10.150.53.228",
    PORT: 9003,
    PROTOCOL: "http",
    SOCKET_PORT: 9004
};